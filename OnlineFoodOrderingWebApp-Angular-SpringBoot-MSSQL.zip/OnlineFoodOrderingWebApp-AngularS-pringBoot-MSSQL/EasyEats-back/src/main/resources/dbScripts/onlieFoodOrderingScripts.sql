
CREATE TABLE userTable
(
  username VARCHAR(45) NOT NULL,
  password  VARCHAR(45) NULL,
  firstname VARCHAR(45) NOT NULL,
  lastname  VARCHAR(45) NULL,
  email     VARCHAR(45) NULL,
  address   VARCHAR(45) NULL,
  phone		VARCHAR(45) NULL,
  merchant varchar(45) NULL,
  PRIMARY KEY (username)
);

insert into usertable values('karthick','Karthick@2396','Karthick','Shanmugam','karthickhcky@gmail.com','1/199B, Attur, Salem','8056719556','User')

CREATE TABLE Restaurant
(
  resId VARCHAR(20) NOT NULL,
  restaurant_Name VARCHAR(45) NOT NULL,
  branch  VARCHAR(45) NULL,
  rating float,
  reviews  VARCHAR(45) NULL,
  res_email     VARCHAR(45) NULL,
  resaddress   VARCHAR(45) NULL,
  owner_Name		VARCHAR(45) NULL,
  url VARCHAR(50) NULL,
  PRIMARY KEY (resId)
);

insert into Restaurant values('FODAL01','FoodAholic','Navalur',4.2,'27','foodaholicm@gmail.com','Navalur','Karthick','..//assets//images//foodaholic.jpg')
insert into Restaurant values('CSK01','CSK Kitchen','Padur',3.9,'31','thecsk@gmail.com','Padur','Karthick','..//assets//images//csk.jpg')
insert into Restaurant values('GUMGUM01','GumaGumalu','Navalur',4.0,'25','gumgum@gmail.com','Navalur','Karthick','..//assets//images//gumagumalu.jpg')
insert into Restaurant values('HunMOD01','Hungry Mode','Kelambakkam',3.6,'35','hungrymode@gmail.com','Kelambakkam','Karthick','..//assets//images//hungrymode.jpg')
insert into Restaurant values('SPICHUT01','Spicy Hut','Navalur',4.3,'10','spicyhut@gmail.com','Navalur','Karthick','..//assets//images//spicyhut.jpg')


CREATE TABLE food (
   id VARCHAR(45) NOT NULL,
   item VARCHAR(45) NOT NULL,
   price INT NOT NULL,
   quantity INT NOT NULL,
   url VARCHAR(150) NOT NULL ,
   formID VARCHAR(50) NOT NULL ,
   cartID VARCHAR(50) NOT NULL ,
   rating float NULL,
   PRIMARY KEY (id));
   
insert into food values('1','Chicken Biriyani',250,10,'..//assets//images//chkbiriyani.jpg','1','CB',4.5)
insert into food values('2','Chicken Fried Rice',110,15,'..//assets//images//cfr.jpg','1','CFR',4.6)
insert into food values('3','Chicken Lollipop',180,15,'..//assets//images//cl.jpg','1','CL',4.0)
insert into food values('4','Fish Finger',220,12,'..//assets//images//ff.jpg','1','FF',3.8)
insert into food values('5','Mutton Chukka',210,11,'..//assets//images//mc.jpg','1','MC',3.9)
insert into food values('6','Veg Fried Rice',100,11,'..//assets//images//vfr.jpg','1','VFR',3.5)
insert into food values('7','Roti Chicken Gravy Combo',100,10,'..//assets//images//rcgc.jpg','1','RCGC',3.4)
insert into food values('8','Dragon Chicken',180,10,'..//assets//images//chkbiriyani.jpg','1','DC',3.2)
insert into food values('9','Parota Egg Stir Combo',100,10,'..//assets//images//food.jpg','1','PEPC',3.1)


CREATE TABLE cart (
  quantity1 INT,
  quantity2 INT,
  quantity3 INT,
  quantity4 INT,
  quantity5 INT,
  quantity6 INT,
  quantity7 INT,
  quantity8 INT,
  quantity9 INT 
);
