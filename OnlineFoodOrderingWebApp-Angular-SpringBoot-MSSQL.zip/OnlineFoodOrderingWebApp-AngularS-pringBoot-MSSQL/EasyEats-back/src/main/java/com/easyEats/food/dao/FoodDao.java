package com.easyEats.food.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.easyEats.food.model.Food;


public interface FoodDao extends JpaRepository<Food,String> {

}
