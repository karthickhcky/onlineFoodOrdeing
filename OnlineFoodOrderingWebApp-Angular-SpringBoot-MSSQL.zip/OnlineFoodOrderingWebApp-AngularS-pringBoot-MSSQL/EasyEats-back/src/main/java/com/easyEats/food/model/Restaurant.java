package com.easyEats.food.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Restaurant {
    @Id
    private String restaurantName;
    private String branch;
    private float rating;
    private String reviews;
    private String resEmail;
    private String resaddress;
    private String ownerName;
    private String url;

    public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getRestaurantName() {
		return restaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getReviews() {
		return reviews;
	}

	public void setReviews(String reviews) {
		this.reviews = reviews;
	}

	public String getResEmail() {
		return resEmail;
	}

	public void setResEmail(String resEmail) {
		this.resEmail = resEmail;
	}

	public String getResaddress() {
		return resaddress;
	}

	public void setResaddress(String resaddress) {
		this.resaddress = resaddress;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public Restaurant() {

    }

    public Restaurant(String restaurantName, String branch, int rating, String reviews, String resEmail, String resaddress, String ownerName, String url) {
        this.restaurantName = restaurantName;
        this.branch = branch;
        this.rating = rating;
        this.reviews = reviews;
        this.resEmail = resEmail;
        this.resaddress = resaddress;
        this.ownerName = ownerName;
        this.url = url;
    }
    
    @Override
    public String toString() {
        return "restaurant{" +
                "restaurant_Name='" + restaurantName + '\'' +
                ", branch='" + branch + '\'' +
                ", rating='" + rating + '\'' +
                ", reviews='" + reviews + '\'' +
                ", res_Email='" + resEmail + '\'' +
                ", resaddress='" + resaddress + '\'' +
                ", owner_Name=" + ownerName +'\''+
                ", url=" + url +'\''+
                '}';
    }
}
