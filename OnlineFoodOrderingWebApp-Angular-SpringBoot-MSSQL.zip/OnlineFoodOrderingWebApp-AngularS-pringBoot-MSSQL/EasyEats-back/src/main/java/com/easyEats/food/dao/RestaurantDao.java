package com.easyEats.food.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.easyEats.food.model.Restaurant;

public interface RestaurantDao extends JpaRepository<Restaurant,String> {

}
