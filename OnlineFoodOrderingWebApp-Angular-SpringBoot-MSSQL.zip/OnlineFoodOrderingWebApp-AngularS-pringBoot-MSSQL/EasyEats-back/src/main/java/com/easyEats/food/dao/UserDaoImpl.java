package com.easyEats.food.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.easyEats.food.model.Login;
import com.easyEats.food.model.User;
import com.easyEats.food.model.Usertable;

@Service
public class UserDaoImpl{

    @Autowired
    private UserDao userDao;


    public void register(Usertable user) {
        userDao.save(user);
    }

    public Usertable validateUser(Login login) {
        Usertable user = null;
        if (userDao.findById(login.getUsername()).isPresent()) {
            user = userDao.findById(login.getUsername()).get();
            if(!user.getPassword().equals(login.getPassword()))
                user=null;
        }
        return user;
    }

    public Boolean usernameExists(String username){
       return userDao.findById(username).isPresent();
    }

}
