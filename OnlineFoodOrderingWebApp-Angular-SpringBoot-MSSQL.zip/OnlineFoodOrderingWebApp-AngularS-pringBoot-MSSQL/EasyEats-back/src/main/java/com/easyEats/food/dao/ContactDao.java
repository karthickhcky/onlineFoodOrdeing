package com.easyEats.food.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.easyEats.food.model.Contact;

public interface ContactDao extends JpaRepository<Contact,Integer> {
}
