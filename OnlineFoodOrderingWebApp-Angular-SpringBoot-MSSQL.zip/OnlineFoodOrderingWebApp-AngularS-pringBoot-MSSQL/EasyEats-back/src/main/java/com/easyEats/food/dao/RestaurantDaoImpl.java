package com.easyEats.food.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.easyEats.food.model.Restaurant;

@Service
public class RestaurantDaoImpl {
	@Autowired
	private RestaurantDao restDao;

	public List<Restaurant> getRestList(){
		List<Restaurant> rest;
		rest = restDao.findAll();
		return rest;
	}

	public Restaurant validateFoodInfo(String productId){
		Restaurant rest = null;
		rest = restDao.findById(productId).get();
		return rest;
	}
}
