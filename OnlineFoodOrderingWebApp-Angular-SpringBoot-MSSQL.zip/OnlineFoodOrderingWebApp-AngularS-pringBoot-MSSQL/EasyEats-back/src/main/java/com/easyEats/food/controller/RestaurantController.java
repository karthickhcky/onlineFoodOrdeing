package com.easyEats.food.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.easyEats.food.dao.RestaurantDaoImpl;
import com.easyEats.food.model.Restaurant;

@RestController
@CrossOrigin
public class RestaurantController {

	@Autowired
    RestaurantDaoImpl restDao;

    @RequestMapping(value = "/restMenu")
    public List<Restaurant> getRestMenu(Model model) {
        List<Restaurant> resItems ;
        resItems = restDao.getRestList();
        return resItems;
    }

}
