import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class restServiceService {

  constructor(public HttpClient: HttpClient) { }
  public getRestaurants():any{
    let url = "http://localhost:8080/restMenu";
    return this.HttpClient.get(url);
  }
}
