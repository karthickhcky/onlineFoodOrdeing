import {ApplicationModule, Component, OnInit} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {Observable} from "rxjs";
import {MenuServiceService} from "../menu-service.service";
import {AppComponent} from "../app.component";
import {count} from "rxjs/operators";

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  searchItem:string;
  model:menu[];
  modelsCopy:menu[];
  values:Quantity[] = [];
  total:number;
  priceurl:string;
  ratingurl:string;
  priceCount:number;
  ratingCount:number;

  modalCart:cart={
    quantity1:0,
    quantity2:0,
    quantity3:0,
    quantity4:0,
    quantity5:0,
    quantity6:0,
    quantity7:0,
    quantity8:0,
    quantity9:0
  };

  constructor(private http:HttpClient, private router:Router,private menuService:MenuServiceService) { }

  ngOnInit() {
    if (sessionStorage.getItem("userData") == null) {
      this.router.navigate(['login']);
    }
    this.getItems();
  }


  clearLocal(){
    sessionStorage.clear();
  }

  getItems():void{
    this.menuService.getItems().subscribe((men: any[]) => {
      this.model = men;
      this.modelsCopy = men;
      this.priceCount = 0;
      this.ratingCount = 0;
      this.priceurl = "..//assets//images//ascDirection.jpg";
      this.ratingurl = "..//assets//images//ascDirection.jpg";
      for (let i=0;i<this.model.length;i++){
        this.values.push(new Quantity());
        this.values[i].quantity=0;
      }
    });
  }

  sortByRating():boolean{
    this.ratingCount = this.ratingCount + 1;
    this.modelsCopy = this.model;
    //console.log(this.modelsCopy);
    if(this.ratingCount % 2 != 0){
      this.ratingurl = "..//assets//images//ascDirection.jpg";
      for(let i = 0; i < this.modelsCopy.length; i++){
        for(let j = i+1; j < this.modelsCopy.length; j++){
          let rating1 = this.modelsCopy[i].rating;
          let rating2 = this.modelsCopy[j].rating;
          let model1 = this.modelsCopy[i];
          let model2 = this.modelsCopy[j];
            if(rating1 > rating2){
              this.modelsCopy[i] = model2;
              this.modelsCopy[j] = model1;
            }
          }
        }
      }
      else{
        this.ratingurl = "..//assets//images//dscDirection.jpg";
        for(let i = 0; i < this.modelsCopy.length; i++){
          for(let j = i+1; j < this.modelsCopy.length; j++){
            let rating1 = this.modelsCopy[i].rating;
            let rating2 = this.modelsCopy[j].rating;
            let model1 = this.modelsCopy[i];
            let model2 = this.modelsCopy[j];
            if(rating1 < rating2){
              this.modelsCopy[i] = model2;
              this.modelsCopy[j] = model1;
            }
          }
        }
      }
      this.model = this.modelsCopy;
      return false;
  }

  sortByPrice():boolean{
    this.priceCount = this.priceCount + 1;
    this.modelsCopy = this.model;
    //console.log(this.modelsCopy);
    if(this.priceCount % 2 != 0){
      this.priceurl = "..//assets//images//ascDirection.jpg";
      for(let i = 0; i < this.modelsCopy.length; i++){
        for(let j = i+1; j < this.modelsCopy.length; j++){
          let price1 = this.modelsCopy[i].price;
          let price2 = this.modelsCopy[j].price;
          let model1 = this.modelsCopy[i];
          let model2 = this.modelsCopy[j];
            if(price1 > price2){
              this.modelsCopy[i] = model2;
              this.modelsCopy[j] = model1;
            }
          }
        }
      }
      else{
        this.priceurl = "..//assets//images//dscDirection.jpg";
        for(let i = 0; i < this.modelsCopy.length; i++){
          for(let j = i+1; j < this.modelsCopy.length; j++){
            let price1 = this.modelsCopy[i].price;
            let price2 = this.modelsCopy[j].price;
            let model1 = this.modelsCopy[i];
            let model2 = this.modelsCopy[j];
            if(price1 < price2){
              this.modelsCopy[i] = model2;
              this.modelsCopy[j] = model1;
            }
          }
        }
      }
      this.model = this.modelsCopy;
      return false;
  }

  search():void {
      let term = this.searchItem;
      term = term.toUpperCase();
      console.log(this.modelsCopy);
      this.model = this.modelsCopy.filter(function(tag) {
          return tag.item.toUpperCase().indexOf(term) >= 0;
      });
  }

  getTotal():void{
    console.log(this.values);
    let url = "http://localhost:8080/cart";
    this.modalCart.quantity1=this.values[0].quantity;
    this.modalCart.quantity2=this.values[1].quantity;
    this.modalCart.quantity3=this.values[2].quantity;
    this.modalCart.quantity4=this.values[3].quantity;
    this.modalCart.quantity5=this.values[4].quantity;
    this.modalCart.quantity6=this.values[5].quantity;
    this.modalCart.quantity7=this.values[6].quantity;
    this.modalCart.quantity8=this.values[7].quantity;
    this.modalCart.quantity9=this.values[8].quantity;
    this.http.post<number>(url,this.values).subscribe(

      res=>{
        // AppComponent.total=res;
        sessionStorage.setItem('total',res.toString());
        this.total=res;
      },
      err=>{
        alert("Please add at least 1 item in your cart");
      }
    )

  }
}

export interface menu {
  id:string;
  item:string;
  price:number;
  quantity:number;
  url:string;
  formID:string;
  cartID:string;
  rating:number;
}

export interface cart {
  quantity1:number;
  quantity2:number;
  quantity3:number;
  quantity4:number;
  quantity5:number;
  quantity6:number;
  quantity7:number;
  quantity8:number;
  quantity9:number;

}

export class Quantity {
  quantity:number;
}
