import {ApplicationModule, Component, OnInit} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {Observable} from "rxjs";
import {restServiceService} from "../restaurant-service.service";
import {AppComponent} from "../app.component";
import {count} from "rxjs/operators";

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.css']
})
export class restComponent implements OnInit {

  searchRest:string;
  resLists:resList[];
  resListsCopy:resList[];
  values:restaurants[] = [];
  total:number;
  reviewurl:string;
  ratingurl:string;
  reviewCount:number;
  ratingCount:number;

  constructor(private http:HttpClient, private router:Router,private restService:restServiceService) { }

  ngOnInit() {
    if (sessionStorage.getItem("userData") == null) {
      this.router.navigate(['login']);
    }
    this.getRestaurants();
  }


  clearLocal(){
    sessionStorage.clear();
  }

  getRestaurants():void{
    this.restService.getRestaurants().subscribe((res: any[]) => {
      this.resLists = res;
      this.resListsCopy = res;
      this.reviewCount = 0;
      this.ratingCount = 0;
      this.reviewurl = "..//assets//images//ascDirection.jpg";
      this.ratingurl = "..//assets//images//ascDirection.jpg";
      for (let i=0;i<this.resLists.length;i++){
        console.log(this.resLists[i]);
        this.values.push(new restaurants());
      }
    });
  }

  searchRests():void {
      let term = this.searchRest;
      term = term.toUpperCase();
      this.resLists = this.resListsCopy.filter(function(tag) {
          return tag.restaurantName.toUpperCase().indexOf(term) >= 0;
      });
  }


  sortByRating(): boolean{
    this.ratingCount = this.ratingCount + 1;
    this.resListsCopy = this.resLists;
    //console.log(this.modelsCopy);
    if(this.ratingCount % 2 != 0){
      this.ratingurl = "..//assets//images//ascDirection.jpg";
      for(let i = 0; i < this.resListsCopy.length; i++){
        for(let j = i+1; j < this.resListsCopy.length; j++){
          let rating1 = this.resListsCopy[i].rating;
          let rating2 = this.resListsCopy[j].rating;
          let model1 = this.resListsCopy[i];
          let model2 = this.resListsCopy[j];
            if(rating1 > rating2){
              this.resListsCopy[i] = model2;
              this.resListsCopy[j] = model1;
            }
          }
        }
      }
      else{
        this.ratingurl = "..//assets//images//dscDirection.jpg";
        for(let i = 0; i < this.resListsCopy.length; i++){
          for(let j = i+1; j < this.resListsCopy.length; j++){
            let rating1 = this.resListsCopy[i].rating;
            let rating2 = this.resListsCopy[j].rating;
            let model1 = this.resListsCopy[i];
            let model2 = this.resListsCopy[j];
            if(rating1 < rating2){
              this.resListsCopy[i] = model2;
              this.resListsCopy[j] = model1;
            }
          }
        }
      }
      this.resLists = this.resListsCopy;
      return false;
  }

  sortByReviews():boolean{
    this.reviewCount = this.reviewCount + 1;
    this.resListsCopy = this.resLists;
    //console.log(this.modelsCopy);
    if(this.reviewCount % 2 != 0){
      this.reviewurl = "..//assets//images//ascDirection.jpg";
      for(let i = 0; i < this.resListsCopy.length; i++){
        for(let j = i+1; j < this.resListsCopy.length; j++){
          let price1 = this.resListsCopy[i].reviews;
          let price2 = this.resListsCopy[j].reviews;
          let model1 = this.resListsCopy[i];
          let model2 = this.resListsCopy[j];
            if(price1 > price2){
              this.resListsCopy[i] = model2;
              this.resListsCopy[j] = model1;
            }
          }
        }
      }
      else{
        this.reviewurl = "..//assets//images//dscDirection.jpg";
        for(let i = 0; i < this.resListsCopy.length; i++){
          for(let j = i+1; j < this.resListsCopy.length; j++){
            let price1 = this.resListsCopy[i].reviews;
            let price2 = this.resListsCopy[j].reviews;
            let model1 = this.resListsCopy[i];
            let model2 = this.resListsCopy[j];
            if(price1 < price2){
              this.resListsCopy[i] = model2;
              this.resListsCopy[j] = model1;
            }
          }
        }
      }
      this.resLists = this.resListsCopy;
      return false;
  }
}

export interface resList {
  id:string;
  restaurantName:string;
  branch:string;
  rating:number;
  reviews:number;
  url:string;
  ownerName:string;
}


export class restaurants {
  quantity:number;
}
